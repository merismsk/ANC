#!/usr/bin/env python3
"""
COMPARABLE SWEEP — Same config as local M4 sweep for fair comparison.

Uses the EXACT same hyperparameters as the local overnight sweep so results
are directly comparable across hardware. Only difference is CUDA backend.

Config matches parallel_sweep / run_overnight.py:
  max_train_files=100, max_test_files=50
  epochs_predictor=5, epochs_controller=5
  batch_size=32, history_len=64
  4 horizons × 4 alphas × 2 seeds × 4 predictors = 128 experiments

Estimated time on A100: ~1-2 hours

Usage:
    python run_sweep_comparable.py
"""

from __future__ import annotations

import csv
import gc
import json
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))

from pred_anc.experiment import ExperimentConfig, run_experiment
from pred_anc.models import (
    CausalConvController,
    LinearPredictor,
    PatchTransformerPredictor,
    TcnPredictor,
    TransformerPredictor,
)
from pred_anc.plots import render_run_plots


# ════════════════════════════════════════════════════════════════════════
# CONFIGURATION — Identical to local sweep for fair comparison
# ════════════════════════════════════════════════════════════════════════

HORIZONS = [8, 16, 32, 64]
ALPHAS = [1.5, 2.0, 3.0, 5.0]
SEEDS = [42, 123]

BASE_CONFIG = dict(
    max_train_files=100,       # SAME as local
    max_test_files=50,
    epochs_predictor=5,
    epochs_controller=5,
    batch_size=32,             # SAME as local
    clip_len=16000,
    nonlin_kind="tanh",
    history_len=64,            # SAME as local
)

PREDICTOR_CONFIGS = {
    "linear": {
        "class": LinearPredictor,
        "kwargs": lambda P: dict(
            history_len=64, prediction_len=P,
        ),
    },
    "tcn": {
        "class": TcnPredictor,
        "kwargs": lambda P: dict(
            history_len=64, prediction_len=P,
            channels=32, depth=4,
        ),
    },
    "transformer": {
        "class": TransformerPredictor,
        "kwargs": lambda P: dict(
            history_len=64, prediction_len=P,
            d_model=64, nhead=4, num_layers=4, dropout=0.1,
        ),
    },
    "patch_transformer": {
        "class": PatchTransformerPredictor,
        "kwargs": lambda P: dict(
            history_len=64, prediction_len=P,
            patch_size=8, d_model=128, nhead=4, num_layers=4, dropout=0.1,
        ),
    },
}

OUT_ROOT = Path(__file__).resolve().parent / "runs" / "comparable_sweep"


def clear_gpu_memory():
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def main():
    print("=" * 70, flush=True)
    print("COMPARABLE SWEEP (same config as local M4 sweep)", flush=True)
    print(f"Started: {datetime.now()}", flush=True)
    print("=" * 70, flush=True)

    if torch.cuda.is_available():
        print(f"CUDA Device: {torch.cuda.get_device_name(0)}", flush=True)
        mem_total = torch.cuda.get_device_properties(0).total_mem / 1e9
        print(f"GPU Memory: {mem_total:.1f} GB", flush=True)

    print(f"\nConfig:", flush=True)
    for k, v in BASE_CONFIG.items():
        print(f"  {k}: {v}", flush=True)
    print(f"\nPredictors: {list(PREDICTOR_CONFIGS.keys())}", flush=True)
    print(f"Horizons: {HORIZONS}", flush=True)
    print(f"Alphas: {ALPHAS}", flush=True)
    print(f"Seeds: {SEEDS}", flush=True)

    OUT_ROOT.mkdir(parents=True, exist_ok=True)

    args_list = []
    for pred_name in PREDICTOR_CONFIGS:
        for P in HORIZONS:
            for alpha in ALPHAS:
                for seed in SEEDS:
                    args_list.append((pred_name, P, alpha, seed))

    total = len(args_list)
    print(f"\nTotal experiments: {total}", flush=True)

    start_time = datetime.now()
    all_rows = []
    experiment_times = []
    summary_path = OUT_ROOT / "sweeps_summary.csv"

    for idx, (pred_name, P, alpha, seed) in enumerate(args_list, 1):
        stride = P
        run_name = f"{pred_name}_P{P}_a{alpha}_seed{seed}"

        metrics_file = OUT_ROOT / run_name / "metrics.json"
        if metrics_file.exists():
            try:
                data = json.loads(metrics_file.read_text())
                if data.get("records") and len(data["records"]) == 3:
                    print(f"\n[{idx}/{total}] {run_name} — SKIPPING (already done)", flush=True)
                    for rec in data["records"]:
                        row = {
                            "predictor": pred_name, "P": P, "alpha": alpha,
                            "seed": seed, "stride": stride, **rec,
                            "run_dir": str(OUT_ROOT / run_name),
                        }
                        all_rows.append(row)
                    continue
            except Exception:
                pass

        exp_start = time.time()
        print(f"\n{'='*60}", flush=True)
        print(f"[{idx}/{total}] {run_name}", flush=True)
        print(f"  Predictor={pred_name}, P={P}, alpha={alpha}, seed={seed}", flush=True)

        cfg = ExperimentConfig(
            **BASE_CONFIG,
            seed=seed,
            horizon=P,
            pred_update_stride=stride,
            alpha=alpha,
            run_name=run_name,
            out_dir=str(OUT_ROOT),
        )

        pcfg = PREDICTOR_CONFIGS[pred_name]
        predictor = pcfg["class"](**pcfg["kwargs"](P))
        controller_reactive = CausalConvController(in_ch=1, channels=32, depth=5, kernel_size=7)
        controller_predictive = CausalConvController(in_ch=1 + P, channels=32, depth=5, kernel_size=7)

        try:
            run_dir = run_experiment(cfg, predictor, controller_reactive, controller_predictive)
            try:
                render_run_plots(run_dir)
            except Exception as plot_err:
                print(f"  (plots failed: {plot_err}, continuing)", flush=True)

            metrics = json.loads((Path(run_dir) / "metrics.json").read_text())
            for rec in metrics.get("records", []):
                row = {
                    "predictor": pred_name, "P": P, "alpha": alpha,
                    "seed": seed, "stride": stride, **rec,
                    "run_dir": str(run_dir),
                }
                all_rows.append(row)

            exp_time = time.time() - exp_start
            experiment_times.append(exp_time)
            avg_time = sum(experiment_times) / len(experiment_times)
            remaining = (total - idx) * avg_time
            print(f"  Done in {exp_time:.1f}s | Avg: {avg_time:.0f}s | "
                  f"Remaining: ~{remaining/3600:.1f}h", flush=True)

        except Exception as e:
            print(f"  FAILED: {e}", flush=True)
            import traceback
            traceback.print_exc()
            continue
        finally:
            clear_gpu_memory()

        if all_rows:
            fieldnames = sorted(all_rows[0].keys())
            with summary_path.open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=fieldnames)
                w.writeheader()
                w.writerows(all_rows)

    elapsed_total = datetime.now() - start_time
    print(f"\n{'='*70}", flush=True)
    print(f"SWEEP COMPLETE — Total time: {elapsed_total}", flush=True)
    print(f"{'='*70}", flush=True)
    print(f"\nResults saved to: {summary_path}", flush=True)


if __name__ == "__main__":
    main()
