#!/usr/bin/env python3
"""
A100 FULL SWEEP — All predictors, full data, large batches.

Optimized for NVIDIA A100 (40/80 GB VRAM):
- Large batch sizes (128) — A100 has massive memory
- All 4 predictors: Linear, TCN, Transformer, PatchTransformer
- Full data: 400 train, 200 test files
- More epochs: 10 predictor, 8 controller
- Larger models (d_model=128 for Transformer)
- 4 horizons × 4 alphas × 3 seeds × 4 predictors = 192 experiments

Estimated time on A100: ~3-4 hours (vs ~8+ hours on M4 Mac)

Usage:
    # Basic run (uses ./data/ by default)
    python run_sweep_a100.py

    # Custom data paths
    ESC50_ROOT=/path/to/ESC-50-master REVERBDB_ROOT=/path/to/BUT_ReverbDB python run_sweep_a100.py

    # Resume after interruption (automatic — skips completed experiments)
    python run_sweep_a100.py

    # With nohup for long runs
    nohup env PYTHONUNBUFFERED=1 python run_sweep_a100.py > sweep.log 2>&1 &
"""

from __future__ import annotations

import csv
import gc
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import torch

sys.path.insert(0, str(Path(__file__).resolve().parent))

from pred_anc.experiment import ExperimentConfig, run_experiment
from pred_anc.models import (
    CausalConvController,
    LinearPredictor,
    PatchTransformerPredictor,
    TcnPredictor,
    TransformerPredictor,
)
from pred_anc.plots import render_run_plots


# ════════════════════════════════════════════════════════════════════════
# CONFIGURATION — Tuned for A100
# ════════════════════════════════════════════════════════════════════════

HORIZONS = [8, 16, 32, 64]
ALPHAS = [1.5, 2.0, 3.0, 5.0]
SEEDS = [42, 123, 777]

BASE_CONFIG = dict(
    max_train_files=400,        # Full dataset — A100 can handle it
    max_test_files=200,
    epochs_predictor=10,        # More epochs for convergence
    epochs_controller=8,
    batch_size=128,             # A100 has 40-80GB VRAM
    clip_len=16000,
    nonlin_kind="tanh",
    history_len=128,            # Longer history for better context
    windows_per_waveform=300,   # More training windows
)

PREDICTOR_CONFIGS = {
    "linear": {
        "class": LinearPredictor,
        "kwargs": lambda P: dict(
            history_len=BASE_CONFIG["history_len"],
            prediction_len=P,
        ),
    },
    "tcn": {
        "class": TcnPredictor,
        "kwargs": lambda P: dict(
            history_len=BASE_CONFIG["history_len"],
            prediction_len=P,
            channels=64,         # Bigger TCN
            depth=5,
        ),
    },
    "transformer": {
        "class": TransformerPredictor,
        "kwargs": lambda P: dict(
            history_len=BASE_CONFIG["history_len"],
            prediction_len=P,
            d_model=128,         # Larger model — A100 can handle it
            nhead=8,
            num_layers=6,        # Deeper
            dropout=0.1,
        ),
    },
    "patch_transformer": {
        "class": PatchTransformerPredictor,
        "kwargs": lambda P: dict(
            history_len=BASE_CONFIG["history_len"],
            prediction_len=P,
            patch_size=16,       # Larger patches for H=128
            d_model=256,         # Bigger model
            nhead=8,
            num_layers=6,
            dropout=0.1,
        ),
    },
}

OUT_ROOT = Path(__file__).resolve().parent / "runs" / "a100_sweep"


def clear_gpu_memory():
    """Aggressively clear GPU memory between experiments."""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()


def print_gpu_info():
    """Print GPU memory usage."""
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            mem_alloc = torch.cuda.memory_allocated(i) / 1e9
            mem_reserved = torch.cuda.memory_reserved(i) / 1e9
            mem_total = torch.cuda.get_device_properties(i).total_mem / 1e9
            print(f"  GPU {i} ({torch.cuda.get_device_name(i)}): "
                  f"{mem_alloc:.1f}/{mem_total:.1f} GB allocated, "
                  f"{mem_reserved:.1f} GB reserved", flush=True)


def main():
    print("=" * 70, flush=True)
    print("A100 FULL SWEEP — All Predictors, Full Data", flush=True)
    print(f"Started: {datetime.now()}", flush=True)
    print("=" * 70, flush=True)

    # Print device info
    if torch.cuda.is_available():
        print(f"\nCUDA Device: {torch.cuda.get_device_name(0)}", flush=True)
        print(f"CUDA Version: {torch.version.cuda}", flush=True)
        mem_total = torch.cuda.get_device_properties(0).total_mem / 1e9
        print(f"GPU Memory: {mem_total:.1f} GB", flush=True)

        # Adjust batch size based on GPU memory
        if mem_total < 20:  # e.g., T4 (16GB)
            BASE_CONFIG["batch_size"] = 32
            print(f"  (Reduced batch_size to 32 for smaller GPU)", flush=True)
        elif mem_total < 45:  # A100-40GB
            BASE_CONFIG["batch_size"] = 128
        else:  # A100-80GB
            BASE_CONFIG["batch_size"] = 256
            print(f"  (Increased batch_size to 256 for 80GB GPU)", flush=True)
    elif torch.backends.mps.is_available():
        print(f"\nUsing Apple Silicon GPU (MPS)", flush=True)
        BASE_CONFIG["batch_size"] = 32
        print(f"  (Reduced batch_size to 32 for MPS)", flush=True)
    else:
        print(f"\nWARNING: No GPU detected, using CPU (will be very slow)", flush=True)
        BASE_CONFIG["batch_size"] = 16

    print(f"\nConfig:", flush=True)
    for k, v in BASE_CONFIG.items():
        print(f"  {k}: {v}", flush=True)
    print(f"\nPredictors: {list(PREDICTOR_CONFIGS.keys())}", flush=True)
    print(f"Horizons: {HORIZONS}", flush=True)
    print(f"Alphas: {ALPHAS}", flush=True)
    print(f"Seeds: {SEEDS}", flush=True)

    OUT_ROOT.mkdir(parents=True, exist_ok=True)

    # Build experiment list
    args_list = []
    for pred_name in PREDICTOR_CONFIGS:
        for P in HORIZONS:
            for alpha in ALPHAS:
                for seed in SEEDS:
                    args_list.append((pred_name, P, alpha, seed))

    total = len(args_list)
    print(f"\nTotal experiments: {total}", flush=True)
    print_gpu_info()

    start_time = datetime.now()
    all_rows = []
    experiment_times = []
    summary_path = OUT_ROOT / "sweeps_summary.csv"
    skipped = 0

    for idx, (pred_name, P, alpha, seed) in enumerate(args_list, 1):
        stride = P
        run_name = f"{pred_name}_P{P}_a{alpha}_seed{seed}"

        # Resume support: skip completed experiments
        metrics_file = OUT_ROOT / run_name / "metrics.json"
        if metrics_file.exists():
            try:
                data = json.loads(metrics_file.read_text())
                if data.get("records") and len(data["records"]) == 3:
                    print(f"\n[{idx}/{total}] {run_name} — SKIPPING (already done)", flush=True)
                    for rec in data["records"]:
                        row = {
                            "predictor": pred_name, "P": P, "alpha": alpha,
                            "seed": seed, "stride": stride, **rec,
                            "run_dir": str(OUT_ROOT / run_name),
                        }
                        all_rows.append(row)
                    skipped += 1
                    continue
            except Exception:
                pass

        exp_start = time.time()
        print(f"\n{'='*60}", flush=True)
        print(f"[{idx}/{total}] {run_name}", flush=True)
        print(f"  Predictor={pred_name}, P={P}, alpha={alpha}, seed={seed}", flush=True)
        print_gpu_info()

        cfg = ExperimentConfig(
            **BASE_CONFIG,
            seed=seed,
            horizon=P,
            pred_update_stride=stride,
            alpha=alpha,
            run_name=run_name,
            out_dir=str(OUT_ROOT),
        )

        # Create models
        pcfg = PREDICTOR_CONFIGS[pred_name]
        predictor = pcfg["class"](**pcfg["kwargs"](P))
        controller_reactive = CausalConvController(in_ch=1, channels=32, depth=5, kernel_size=7)
        controller_predictive = CausalConvController(in_ch=1 + P, channels=32, depth=5, kernel_size=7)

        try:
            # Use proven run_experiment()
            run_dir = run_experiment(cfg, predictor, controller_reactive, controller_predictive)
            try:
                render_run_plots(run_dir)
            except Exception as plot_err:
                print(f"  (plots failed: {plot_err}, continuing)", flush=True)

            # Read metrics
            metrics = json.loads((Path(run_dir) / "metrics.json").read_text())
            for rec in metrics.get("records", []):
                row = {
                    "predictor": pred_name, "P": P, "alpha": alpha,
                    "seed": seed, "stride": stride, **rec,
                    "run_dir": str(run_dir),
                }
                all_rows.append(row)

            exp_time = time.time() - exp_start
            experiment_times.append(exp_time)
            avg_time = sum(experiment_times) / len(experiment_times)
            remaining = (total - idx) * avg_time

            print(f"  Done in {exp_time:.1f}s | Avg: {avg_time:.0f}s | "
                  f"Remaining: ~{remaining/3600:.1f}h ({remaining/60:.0f} min)", flush=True)

        except Exception as e:
            print(f"  FAILED: {e}", flush=True)
            import traceback
            traceback.print_exc()
            continue
        finally:
            # Always clear GPU memory after each experiment
            clear_gpu_memory()

        # Save intermediate CSV
        if all_rows:
            fieldnames = sorted(all_rows[0].keys())
            with summary_path.open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=fieldnames)
                w.writeheader()
                w.writerows(all_rows)

        # Periodic summary every 8 experiments
        completed = idx - skipped
        if completed % 8 == 0 and completed > 0:
            _print_interim_summary(all_rows, idx, total)

    # Final summary
    elapsed_total = datetime.now() - start_time
    print(f"\n{'='*70}", flush=True)
    print(f"SWEEP COMPLETE", flush=True)
    print(f"{'='*70}", flush=True)
    print(f"Total time: {elapsed_total}", flush=True)
    print(f"Experiments: {total - skipped} run + {skipped} skipped = {total} total", flush=True)

    if all_rows:
        _print_final_summary(all_rows)

    print(f"\nResults saved to: {summary_path}", flush=True)
    print(f"Finished: {datetime.now()}", flush=True)


def _print_interim_summary(all_rows, idx, total):
    print(f"\n{'─'*60}", flush=True)
    print(f"INTERIM SUMMARY (after {idx}/{total})", flush=True)
    print(f"{'─'*60}", flush=True)
    for pname in PREDICTOR_CONFIGS:
        pred_rows = [r for r in all_rows if r['predictor'] == pname]
        if not pred_rows:
            continue
        react = [abs(float(r['nr_db_pos_mean'])) for r in pred_rows if r['mode'] == 'reactive']
        predicted = [abs(float(r['nr_db_pos_mean'])) for r in pred_rows if r['mode'] == 'predicted']
        if react and predicted:
            gain = np.mean(predicted) - np.mean(react)
            print(f"  {pname}: reactive={np.mean(react):.2f}, "
                  f"predicted={np.mean(predicted):.2f}, "
                  f"gain={gain:+.2f} dB", flush=True)
    print(f"{'─'*60}\n", flush=True)


def _print_final_summary(all_rows):
    for pname in PREDICTOR_CONFIGS:
        pred_rows = [r for r in all_rows if r['predictor'] == pname]
        if not pred_rows:
            continue
        reactive = [abs(float(r['nr_db_pos_mean'])) for r in pred_rows if r['mode'] == 'reactive']
        predicted = [abs(float(r['nr_db_pos_mean'])) for r in pred_rows if r['mode'] == 'predicted']
        oracle = [abs(float(r['nr_db_pos_mean'])) for r in pred_rows if r['mode'] == 'oracle']

        react_map, pred_map = {}, {}
        for r in pred_rows:
            key = (r['P'], r['alpha'], r['seed'])
            if r['mode'] == 'reactive':
                react_map[key] = abs(float(r['nr_db_pos_mean']))
            elif r['mode'] == 'predicted':
                pred_map[key] = abs(float(r['nr_db_pos_mean']))
        improvements = [pred_map[k] - react_map[k] for k in pred_map if k in react_map]
        wins = sum(1 for x in improvements if x > 0)

        print(f"\n  {pname.upper()}:", flush=True)
        print(f"    Reactive:  {np.mean(reactive):.2f} +/- {np.std(reactive):.2f} dB", flush=True)
        print(f"    Predicted: {np.mean(predicted):.2f} +/- {np.std(predicted):.2f} dB", flush=True)
        print(f"    Oracle:    {np.mean(oracle):.2f} +/- {np.std(oracle):.2f} dB", flush=True)
        if improvements:
            print(f"    Gain: {np.mean(improvements):+.2f} dB | "
                  f"Win rate: {wins}/{len(improvements)} "
                  f"({100*wins/len(improvements):.0f}%)", flush=True)


if __name__ == "__main__":
    main()
