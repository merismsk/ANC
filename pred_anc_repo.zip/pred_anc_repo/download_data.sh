#!/bin/bash
# Download ESC-50 and BUT ReverbDB datasets
# Usage: bash download_data.sh [DATA_DIR]
# Default DATA_DIR: ./data

set -e

DATA_DIR="${1:-./data}"
mkdir -p "$DATA_DIR"

echo "=============================================="
echo "Downloading datasets to: $DATA_DIR"
echo "=============================================="

# ─── ESC-50 (~600 MB) ───
ESC50_DIR="$DATA_DIR/ESC-50-master"
if [ -d "$ESC50_DIR/audio" ]; then
    echo "✓ ESC-50 already exists at $ESC50_DIR"
else
    echo "Downloading ESC-50..."
    cd "$DATA_DIR"
    wget -q --show-progress https://github.com/karolpiczak/ESC-50/archive/master.zip -O esc50.zip
    unzip -q esc50.zip
    rm esc50.zip
    cd -
    echo "✓ ESC-50 downloaded ($(ls "$ESC50_DIR/audio/" | wc -l) audio files)"
fi

# ─── BUT ReverbDB RIR-Only (~8.7 GB compressed) ───
REVERBDB_DIR="$DATA_DIR/BUT_ReverbDB"
if [ -d "$REVERBDB_DIR" ] && [ "$(find "$REVERBDB_DIR" -name '*.wav' 2>/dev/null | head -1)" != "" ]; then
    echo "✓ BUT ReverbDB already exists at $REVERBDB_DIR"
else
    echo "Downloading BUT ReverbDB (RIR-Only)..."
    echo "  This is ~8.7 GB, may take a while..."
    cd "$DATA_DIR"
    
    # BUT ReverbDB is hosted at BUT FIT
    # Download the RIR-only package
    wget -q --show-progress \
        "https://speech.fit.vutbr.cz/software/but-speech-fit-reverb-database/BUT_ReverbDB_rel_19_06_RIR-Only.tgz" \
        -O but_reverbdb.tgz || {
        echo "Primary URL failed. Trying alternative..."
        wget -q --show-progress \
            "https://speech.fit.vutbr.cz/BUT_ReverbDB_rel_19_06_RIR-Only.tgz" \
            -O but_reverbdb.tgz
    }
    
    echo "Extracting (this takes a few minutes)..."
    tar xzf but_reverbdb.tgz
    
    # Rename to consistent directory name
    if [ -d "BUT_ReverbDB_rel_19_06_RIR-Only" ] && [ ! -d "BUT_ReverbDB" ]; then
        mv BUT_ReverbDB_rel_19_06_RIR-Only BUT_ReverbDB
    fi
    
    rm -f but_reverbdb.tgz
    cd -
    
    RIR_COUNT=$(find "$REVERBDB_DIR" -name '*.wav' 2>/dev/null | wc -l)
    echo "✓ BUT ReverbDB downloaded ($RIR_COUNT RIR files)"
fi

# ─── Set environment variables ───
echo ""
echo "=============================================="
echo "DATA READY"
echo "=============================================="
echo "ESC-50:    $ESC50_DIR"
echo "ReverbDB:  $REVERBDB_DIR"
echo ""
echo "Set these environment variables before running:"
echo "  export ESC50_ROOT=$ESC50_DIR"
echo "  export REVERBDB_ROOT=$REVERBDB_DIR"
echo ""
echo "Or they will be auto-detected from ./data/"
