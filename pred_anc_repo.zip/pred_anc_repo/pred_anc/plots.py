from __future__ import annotations

from pathlib import Path
from typing import Dict, List

import json
import numpy as np
import matplotlib.pyplot as plt


def plot_loss_curve(loss: List[float], out_path: Path, title: str) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    plt.figure(figsize=(7, 4))
    plt.plot(loss, linewidth=2)
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title(title)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def plot_bar_metrics(records: List[Dict], key: str, out_path: Path, title: str) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    labels = [r["mode"] for r in records]
    vals = [r[key] for r in records]
    plt.figure(figsize=(7, 4))
    plt.bar(labels, vals)
    plt.ylabel(key)
    plt.title(title)
    plt.grid(True, axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_path, dpi=200)
    plt.close()


def render_run_plots(run_dir: Path) -> None:
    metrics_path = run_dir / "metrics.json"
    if not metrics_path.exists():
        return
    metrics = json.loads(metrics_path.read_text())
    records = metrics.get("records", [])
    if not records:
        return

    if "nr_db_pos_mean" in records[0]:
        plot_bar_metrics(records, "nr_db_pos_mean", run_dir / "plots" / "nr_db_pos_mean.png", "Noise reduction (positive is better) mean")
        plot_bar_metrics(records, "nr_db_neg_mean", run_dir / "plots" / "nr_db_neg_mean.png", "Noise reduction (negative is better) mean")
    else:
        plot_bar_metrics(records, "nr_db_mean", run_dir / "plots" / "nr_db_mean.png", "Noise reduction (mean)")
        plot_bar_metrics(records, "nr_db_std", run_dir / "plots" / "nr_db_std.png", "Noise reduction (std)")

    # Attenuation-vs-frequency curves (TASLP-friendly)
    curves = {}
    for mode in ["reactive", "oracle", "predicted"]:
        p = run_dir / "plots" / f"att_curve_{mode}.npz"
        if not p.exists():
            continue
        z = np.load(p)
        curves[mode] = {
            "freq_hz": z["freq_hz"],
            "mean": z["att_db_mean"],
            "std": z["att_db_std"],
        }

    if curves:
        out_path = run_dir / "plots" / "att_curve_compare.png"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        plt.figure(figsize=(8, 4.5))
        for mode, c in curves.items():
            f = c["freq_hz"]
            m = c["mean"]
            s = c["std"]
            plt.plot(f, m, label=mode, linewidth=2)
            plt.fill_between(f, m - s, m + s, alpha=0.15)
        plt.xlim(0, min(4000, float(curves[next(iter(curves))]["freq_hz"][-1])))
        plt.xlabel("Frequency (Hz)")
        plt.ylabel("Attenuation A(f) (dB)")
        plt.title("Frequency-dependent attenuation (mean ± std)")
        plt.grid(True, alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig(out_path, dpi=200)
        plt.close()

