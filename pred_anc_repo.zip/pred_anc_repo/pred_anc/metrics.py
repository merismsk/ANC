from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np


def mse(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a)
    b = np.asarray(b)
    return float(np.mean(np.square(a - b)))


def mae(a: np.ndarray, b: np.ndarray) -> float:
    a = np.asarray(a)
    b = np.asarray(b)
    return float(np.mean(np.abs(a - b)))


def noise_reduction_db(
    error_signal: np.ndarray,
    disturbance_signal: np.ndarray,
    convention: str = "negative_is_better",
    eps: float = 1e-12,
) -> float:
    """
    Two common conventions:
    - "negative_is_better": 10*log10(var(e)/var(d))  (your Paper2 current style)
    - "positive_is_better": 10*log10(var(d)/var(e))  (more common in ANC)
    """

    ve = float(np.var(error_signal) + eps)
    vd = float(np.var(disturbance_signal) + eps)
    if convention == "negative_is_better":
        return 10.0 * float(np.log10(ve / vd))
    if convention == "positive_is_better":
        return 10.0 * float(np.log10(vd / ve))
    raise ValueError(f"Unknown convention: {convention}")


def attenuation_spectrum_db(
    d: np.ndarray,
    e: np.ndarray,
    nfft: int = 2048,
    fs: Optional[int] = None,
    eps: float = 1e-12,
) -> Dict[str, np.ndarray]:
    """
    Frequency-dependent attenuation:
      A(f) = 10 log10( P_d(f) / P_e(f) )
    """

    d = np.asarray(d, dtype=np.float64)
    e = np.asarray(e, dtype=np.float64)
    wd = np.hanning(len(d))
    we = np.hanning(len(e))
    D = np.fft.rfft(d * wd, n=nfft)
    E = np.fft.rfft(e * we, n=nfft)
    Pd = np.abs(D) ** 2
    Pe = np.abs(E) ** 2
    att = 10.0 * np.log10((Pd + eps) / (Pe + eps))
    out: Dict[str, np.ndarray] = {"att_db": att.astype(np.float32)}
    if fs is not None:
        freqs = np.fft.rfftfreq(nfft, d=1.0 / float(fs))
        out["freq_hz"] = freqs.astype(np.float32)
    return out

