from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, List

import numpy as np
import torch


@dataclass(frozen=True)
class FuturePredictionSpec:
    history_len: int
    horizon: int
    update_stride: int = 1  # 1 = update every sample; P = update every P samples


def oracle_future_matrix(x: np.ndarray, spec: FuturePredictionSpec) -> np.ndarray:
    """
    Returns matrix F of shape (P, T) where F[p-1, t] = x[t + p] if in range else 0.
    VECTORIZED: No loops for p.
    """
    x = np.asarray(x, dtype=np.float32)
    T = len(x)
    P = int(spec.horizon)
    F = np.zeros((P, T), dtype=np.float32)
    
    # Vectorized: create shifted views
    for p in range(1, min(P + 1, T)):
        F[p - 1, : T - p] = x[p:]
    return F


@torch.no_grad()
def predicted_future_matrix(
    x: np.ndarray,
    predictor: torch.nn.Module,
    spec: FuturePredictionSpec,
    device: torch.device,
) -> np.ndarray:
    """
    VECTORIZED streaming prediction:
      - Batch all history windows together for a single GPU call
      - Much faster than sample-by-sample prediction
    """
    x = np.asarray(x, dtype=np.float32)
    T = len(x)
    H = int(spec.history_len)
    P = int(spec.horizon)
    stride = max(1, int(spec.update_stride))

    Fmat = np.zeros((P, T), dtype=np.float32)
    predictor.eval()

    # Determine prediction indices
    n0 = H - 1
    n_max = T - P - 1
    if n_max <= n0:
        return Fmat

    # Collect all indices where we need predictions
    pred_indices = list(range(n0, n_max + 1, stride))
    if not pred_indices:
        return Fmat

    # BATCH ALL PREDICTIONS IN ONE GPU CALL
    # Extract all history windows
    batch_size = len(pred_indices)
    hist_batch = np.zeros((batch_size, 1, H), dtype=np.float32)
    for i, n in enumerate(pred_indices):
        hist_batch[i, 0, :] = x[n - H + 1 : n + 1]

    # Chunked GPU call to avoid OOM with large Transformers
    CHUNK_SIZE = 2048
    preds_parts = []
    for start in range(0, batch_size, CHUNK_SIZE):
        end = min(start + CHUNK_SIZE, batch_size)
        chunk = torch.from_numpy(hist_batch[start:end]).to(device)
        preds_parts.append(predictor(chunk).detach().cpu().numpy())
    preds_raw = np.concatenate(preds_parts, axis=0)  # (batch_size, 1, P)
    preds = preds_raw.squeeze(1)  # (batch_size, P)

    # Fill in the future matrix (vectorized where possible)
    for i, n in enumerate(pred_indices):
        pred = preds[i]  # (P,)
        
        # Fill main prediction point
        Fmat[:, n] = pred
        
        # Fill forward for stride (vectorized)
        for dt in range(1, stride):
            t = n + dt
            if t > n_max:
                break
            # Shift predictions for time offset
            k_end = P - dt
            if k_end > 0:
                Fmat[:k_end, t] = pred[dt:dt + k_end]

    return Fmat


@torch.no_grad()
def predicted_future_matrix_batch(
    x_batch: List[np.ndarray],
    predictor: torch.nn.Module,
    spec: FuturePredictionSpec,
    device: torch.device,
) -> List[np.ndarray]:
    """
    Process multiple waveforms in a mega-batch for maximum GPU utilization.
    Returns list of Fmat for each input waveform.
    """
    H = int(spec.history_len)
    P = int(spec.horizon)
    stride = max(1, int(spec.update_stride))
    predictor.eval()
    
    results = []
    
    # Collect ALL history windows from ALL waveforms
    all_histories = []
    all_meta = []  # (waveform_idx, time_idx, T, n_max)
    
    for wave_idx, x in enumerate(x_batch):
        x = np.asarray(x, dtype=np.float32)
        T = len(x)
        n0 = H - 1
        n_max = T - P - 1
        
        if n_max <= n0:
            all_meta.append((wave_idx, [], T, n_max))
            continue
            
        pred_indices = list(range(n0, n_max + 1, stride))
        for n in pred_indices:
            all_histories.append(x[n - H + 1 : n + 1])
        all_meta.append((wave_idx, pred_indices, T, n_max))
    
    if not all_histories:
        return [np.zeros((P, len(x)), dtype=np.float32) for x in x_batch]
    
    # CHUNKED BATCH: Process in sub-batches to avoid GPU OOM
    # Large Transformers can't handle 30k+ windows at once
    CHUNK_SIZE = 2048
    hist_np = np.array(all_histories)[:, None, :]  # (total_windows, 1, H)
    total_windows = hist_np.shape[0]
    
    all_preds_parts = []
    for start in range(0, total_windows, CHUNK_SIZE):
        end = min(start + CHUNK_SIZE, total_windows)
        chunk = torch.tensor(hist_np[start:end], device=device, dtype=torch.float32)
        preds_chunk = predictor(chunk).cpu().numpy()
        all_preds_parts.append(preds_chunk)
    
    all_preds_raw = np.concatenate(all_preds_parts, axis=0)  # (total_windows, 1, P)
    all_preds = all_preds_raw.squeeze(1)  # (total_windows, P)
    
    # Distribute predictions back to waveforms
    pred_offset = 0
    for wave_idx, pred_indices, T, n_max in all_meta:
        Fmat = np.zeros((P, T), dtype=np.float32)
        
        if pred_indices:
            for i, n in enumerate(pred_indices):
                pred = all_preds[pred_offset + i]
                Fmat[:, n] = pred
                
                for dt in range(1, stride):
                    t = n + dt
                    if t > n_max:
                        break
                    k_end = P - dt
                    if k_end > 0:
                        Fmat[:k_end, t] = pred[dt:dt + k_end]
            
            pred_offset += len(pred_indices)
        
        results.append(Fmat)
    
    return results

