from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional

import numpy as np


NonlinType = Literal["linear", "tanh", "clip", "poly3"]


@dataclass(frozen=True)
class NonlinearityConfig:
    kind: NonlinType = "tanh"
    alpha: float = 2.0  # tanh "hardness"
    clip_level: float = 0.8  # for hard clip
    poly_gain: float = 0.5  # for cubic


def apply_nonlinearity(x: np.ndarray, cfg: NonlinearityConfig) -> np.ndarray:
    if cfg.kind == "linear":
        return x
    if cfg.kind == "tanh":
        return np.tanh(cfg.alpha * x)
    if cfg.kind == "clip":
        c = float(cfg.clip_level)
        return np.clip(x, -c, c)
    if cfg.kind == "poly3":
        # Simple memoryless odd nonlinearity. Keep stable by limiting gain.
        g = float(cfg.poly_gain)
        return x - g * (x**3)
    raise ValueError(f"Unknown nonlinearity: {cfg.kind}")

