from __future__ import annotations

import json
import os
import time
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

import numpy as np


def set_seed(seed: int) -> None:
    import random

    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch

        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        if torch.backends.mps.is_available():
            # MPS doesn't have a separate manual_seed, torch.manual_seed covers it
            pass
    except Exception:
        pass


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def now_tag() -> str:
    return time.strftime("%Y%m%d-%H%M%S")


def save_json(path: Path, obj: Any) -> None:
    ensure_dir(path.parent)
    if is_dataclass(obj):
        payload = asdict(obj)
    else:
        payload = obj
    path.write_text(json.dumps(payload, indent=2, sort_keys=True))


def append_jsonl(path: Path, record: Dict[str, Any]) -> None:
    ensure_dir(path.parent)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


class Timer:
    """Tiny wall-clock timer helper."""

    def __init__(self) -> None:
        self._t0: Optional[float] = None

    def __enter__(self) -> "Timer":
        self._t0 = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        pass

    @property
    def elapsed_s(self) -> float:
        if self._t0 is None:
            return 0.0
        return time.perf_counter() - self._t0


def human_bytes(n: float) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    u = 0
    while n >= 1024 and u < len(units) - 1:
        n /= 1024
        u += 1
    return f"{n:.2f} {units[u]}"


def env_path(name: str, default: Optional[str] = None) -> Optional[Path]:
    v = os.environ.get(name, default)
    return Path(v).expanduser() if v else None


def rms(x: np.ndarray, eps: float = 1e-12) -> float:
    return float(np.sqrt(np.mean(np.square(x)) + eps))


def snr_db(clean: np.ndarray, noise: np.ndarray, eps: float = 1e-12) -> float:
    return 10.0 * float(np.log10((np.mean(clean**2) + eps) / (np.mean(noise**2) + eps)))


def normalize_audio(x: np.ndarray, peak: float = 0.999, eps: float = 1e-12) -> np.ndarray:
    m = float(np.max(np.abs(x)) + eps)
    return (x / m) * peak

