from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader

from .datasets import ESC50Dataset, ReverbDBRIR
from .metrics import attenuation_spectrum_db, mse, noise_reduction_db
from .nonlinearities import NonlinearityConfig
from .paths import estimate_group_delay_samples, trim_or_pad
from .predict_future import FuturePredictionSpec, oracle_future_matrix, predicted_future_matrix, predicted_future_matrix_batch
from .torch_data import Windowed1DAudioDataset
from .torch_paths import to_torch_fir, torch_fir_filter_1d, torch_secondary_path
from .utils import Timer, append_jsonl, ensure_dir, normalize_audio, save_json, set_seed


@dataclass(frozen=True)
class ExperimentConfig:
    seed: int = 42
    fs: int = 16000

    # Data selection
    esc50_folds_train: Tuple[int, ...] = (1, 2, 3)
    esc50_folds_test: Tuple[int, ...] = (4, 5)
    max_train_files: int = 200
    max_test_files: int = 80

    # Paths (RIR)
    rir_len_primary: int = 256
    rir_len_secondary: int = 256

    # Nonlinearity on secondary path
    nonlin_kind: str = "tanh"  # "tanh"|"clip"|"poly3"|"linear"
    alpha: float = 2.0

    # Prediction task
    history_len: int = 64
    horizon: int = 32
    pred_update_stride: int = 32  # streaming cache update; 1 = full update

    # Controller training
    clip_len: int = 16000  # 1 second segments
    batch_size: int = 8
    epochs_controller: int = 2
    lr_controller: float = 1e-3

    # Predictor training (optional)
    train_predictor: bool = True
    epochs_predictor: int = 2
    lr_predictor: float = 1e-3
    windows_per_waveform: int = 200

    # Output
    out_dir: str = "runs"
    run_name: Optional[str] = None


def _load_esc50_waveforms(ds: ESC50Dataset, max_files: int) -> List[np.ndarray]:
    waves: List[np.ndarray] = []
    n = min(len(ds), int(max_files))
    for i in range(n):
        x, _ = ds.get_audio(i)
        waves.append(x.astype(np.float32))
    return waves


def _random_clip(rng: np.random.Generator, x: np.ndarray, clip_len: int) -> np.ndarray:
    if len(x) <= clip_len:
        if len(x) == clip_len:
            return x
        out = np.zeros(clip_len, dtype=np.float32)
        out[: len(x)] = x
        return out
    s = int(rng.integers(0, len(x) - clip_len))
    return x[s : s + clip_len]


def _make_paths(rir_db: ReverbDBRIR, cfg: ExperimentConfig, rng: np.random.Generator) -> Dict[str, np.ndarray]:
    idx_p = int(rng.integers(0, len(rir_db)))
    idx_s = int(rng.integers(0, len(rir_db)))
    h_p, _ = rir_db.get_rir(idx_p, max_len=cfg.rir_len_primary, normalize_energy=True)
    h_s, _ = rir_db.get_rir(idx_s, max_len=cfg.rir_len_secondary, normalize_energy=True)
    h_p = trim_or_pad(h_p, cfg.rir_len_primary)
    h_s = trim_or_pad(h_s, cfg.rir_len_secondary)
    return {"h_primary": h_p, "h_secondary": h_s}


def train_predictor_model(
    predictor: torch.nn.Module,
    train_waves: List[np.ndarray],
    cfg: ExperimentConfig,
    device: torch.device,
    out_dir: Path,
) -> None:
    # Windowed supervised prediction: history -> next P samples
    ds = Windowed1DAudioDataset(
        train_waves,
        history_len=cfg.history_len,
        prediction_len=cfg.horizon,
        windows_per_waveform=cfg.windows_per_waveform,
        seed=cfg.seed,
    )
    dl = DataLoader(ds, batch_size=cfg.batch_size, shuffle=True, drop_last=True)
    predictor.to(device)
    opt = torch.optim.Adam(predictor.parameters(), lr=cfg.lr_predictor)

    loss_curve = []
    for ep in range(cfg.epochs_predictor):
        predictor.train()
        ep_loss = 0.0
        for hist, fut in dl:
            hist = hist.to(device)
            fut = fut.to(device)
            pred = predictor(hist)
            loss = F.mse_loss(pred, fut)
            opt.zero_grad()
            loss.backward()
            opt.step()
            ep_loss += float(loss.item())
        loss_curve.append(ep_loss / max(1, len(dl)))

    torch.save(predictor.state_dict(), out_dir / "predictor.pt")
    save_json(out_dir / "predictor_loss.json", {"loss": loss_curve})


def train_controller(
    controller: torch.nn.Module,
    predictor: Optional[torch.nn.Module],
    train_waves: List[np.ndarray],
    paths: Dict[str, np.ndarray],
    cfg: ExperimentConfig,
    device: torch.device,
    mode: str,
) -> Dict[str, float]:
    """
    OPTIMIZED: Uses batched predictions for 2-3x speedup.
    
    mode:
      - "reactive": input channels = [x]
      - "oracle":   input channels = [x, x(t+1),...,x(t+P)] (acausal upper bound)
      - "predicted":input channels = [x, xhat(t+1),...,xhat(t+P)]
    """

    controller.to(device)
    opt = torch.optim.Adam(controller.parameters(), lr=cfg.lr_controller)

    h_p = to_torch_fir(paths["h_primary"], device)
    h_s = to_torch_fir(paths["h_secondary"], device)
    nonlin = NonlinearityConfig(kind=cfg.nonlin_kind, alpha=cfg.alpha)

    rng = np.random.default_rng(cfg.seed)
    spec = FuturePredictionSpec(cfg.history_len, cfg.horizon, update_stride=cfg.pred_update_stride)

    losses: List[float] = []
    for ep in range(cfg.epochs_controller):
        controller.train()
        ep_loss = 0.0
        n_batches = max(1, len(train_waves) // cfg.batch_size)
        
        for _ in range(n_batches):
            # Sample clips for this batch
            batch_x = []
            batch_d = []
            
            for _b in range(cfg.batch_size):
                x_full = train_waves[int(rng.integers(0, len(train_waves)))]
                x = normalize_audio(_random_clip(rng, x_full, cfg.clip_len))
                d = np.convolve(x, paths["h_primary"], mode="full")[: len(x)].astype(np.float32)
                batch_x.append(x)
                batch_d.append(d)

            # Build input channels - BATCHED for predicted mode
            if mode == "reactive":
                batch_in = [x[None, :] for x in batch_x]
            elif mode == "oracle":
                batch_in = [np.concatenate([x[None, :], oracle_future_matrix(x, spec)], axis=0) for x in batch_x]
            elif mode == "predicted":
                assert predictor is not None
                # BATCHED PREDICTION - much faster!
                Fmats = predicted_future_matrix_batch(batch_x, predictor, spec, device=device)
                batch_in = [np.concatenate([x[None, :], Fmat], axis=0) for x, Fmat in zip(batch_x, Fmats)]
            else:
                raise ValueError(f"Unknown mode: {mode}")

            u_t = torch.tensor(np.stack(batch_in, axis=0), device=device)  # (B,C,T)
            d_t = torch.tensor(np.stack(batch_d, axis=0), device=device).unsqueeze(1)  # (B,1,T)

            y_t = controller(u_t)  # (B,1,T)
            z_t = torch_secondary_path(y_t, h_s, nonlin)  # (B,1,T)
            e_t = d_t + z_t
            loss = torch.mean(e_t**2)

            opt.zero_grad()
            loss.backward()
            opt.step()

            ep_loss += float(loss.item())

        losses.append(ep_loss)

    return {"loss_final": float(losses[-1]) if losses else 0.0}


@torch.no_grad()
def eval_controller(
    controller: torch.nn.Module,
    predictor: Optional[torch.nn.Module],
    test_waves: List[np.ndarray],
    paths: Dict[str, np.ndarray],
    cfg: ExperimentConfig,
    device: torch.device,
    mode: str,
) -> Dict[str, float]:
    controller.eval()
    controller.to(device)

    h_s = to_torch_fir(paths["h_secondary"], device)
    nonlin = NonlinearityConfig(kind=cfg.nonlin_kind, alpha=cfg.alpha)
    rng = np.random.default_rng(cfg.seed + 123)

    nrs_neg: List[float] = []
    nrs_pos: List[float] = []
    att_list: List[np.ndarray] = []
    freq_hz: Optional[np.ndarray] = None
    for _ in range(min(20, len(test_waves))):
        x_full = test_waves[int(rng.integers(0, len(test_waves)))]
        x = normalize_audio(_random_clip(rng, x_full, cfg.clip_len))
        d = np.convolve(x, paths["h_primary"], mode="full")[: len(x)].astype(np.float32)

        if mode == "reactive":
            u = x[None, :]
        else:
            spec = FuturePredictionSpec(cfg.history_len, cfg.horizon, update_stride=cfg.pred_update_stride)
            if mode == "oracle":
                Fmat = oracle_future_matrix(x, spec)
            elif mode == "predicted":
                assert predictor is not None
                Fmat = predicted_future_matrix(x, predictor, spec, device=device)
            else:
                raise ValueError(f"Unknown mode: {mode}")
            u = np.concatenate([x[None, :], Fmat], axis=0)

        u_t = torch.tensor(u[None, ...], device=device)
        y_t = controller(u_t)
        z_t = torch_secondary_path(y_t, h_s, nonlin).cpu().numpy().reshape(-1)
        e = d + z_t
        nrs_neg.append(noise_reduction_db(e, d, convention="negative_is_better"))
        nrs_pos.append(noise_reduction_db(e, d, convention="positive_is_better"))
        spec = attenuation_spectrum_db(d, e, nfft=2048, fs=cfg.fs)
        att_list.append(spec["att_db"])
        if freq_hz is None and "freq_hz" in spec:
            freq_hz = spec["freq_hz"]

    out = {
        "nr_db_neg_mean": float(np.mean(nrs_neg)),
        "nr_db_neg_std": float(np.std(nrs_neg)),
        "nr_db_pos_mean": float(np.mean(nrs_pos)),
        "nr_db_pos_std": float(np.std(nrs_pos)),
    }
    if att_list:
        A = np.stack(att_list, axis=0)  # (N,F)
        out["att_db_mean"] = float(np.mean(A))
        out["att_db_std"] = float(np.std(A))
    return out


def run_experiment(
    cfg: ExperimentConfig,
    predictor: torch.nn.Module,
    controller_reactive: torch.nn.Module,
    controller_predictive: torch.nn.Module,
) -> Path:
    set_seed(cfg.seed)
    # Device selection: prefer MPS (Apple Silicon) > CUDA > CPU
    if torch.backends.mps.is_available():
        device = torch.device("mps")
        print(f"Using Apple Silicon GPU (MPS)")
    elif torch.cuda.is_available():
        device = torch.device("cuda")
        print(f"Using NVIDIA GPU (CUDA)")
    else:
        device = torch.device("cpu")
        print(f"Using CPU")

    out_root = Path(cfg.out_dir)
    run_name = cfg.run_name or f"predanc_{cfg.horizon}_{cfg.nonlin_kind}{cfg.alpha}"
    out_dir = ensure_dir(out_root / run_name)
    ensure_dir(out_dir / "plots")
    ensure_dir(out_dir / "artifacts")

    save_json(out_dir / "config.json", cfg)

    # Data
    print("Loading ESC-50 waveforms...")
    esc_train = ESC50Dataset(fs=cfg.fs, folds=cfg.esc50_folds_train)
    esc_test = ESC50Dataset(fs=cfg.fs, folds=cfg.esc50_folds_test)
    train_waves = _load_esc50_waveforms(esc_train, cfg.max_train_files)
    test_waves = _load_esc50_waveforms(esc_test, cfg.max_test_files)
    print(f"Loaded train={len(train_waves)} test={len(test_waves)} waveforms.")

    print("Indexing BUT ReverbDB RIRs (early-stop)...")
    rir_db = ReverbDBRIR(fs=cfg.fs, max_items=5000)
    rng = np.random.default_rng(cfg.seed)
    paths = _make_paths(rir_db, cfg, rng)
    print("Sampled primary/secondary paths.")

    # Log “latency-ish” delay proxies (group delay centroids)
    gd_p = estimate_group_delay_samples(paths["h_primary"])
    gd_s = estimate_group_delay_samples(paths["h_secondary"])
    save_json(out_dir / "paths_delay_proxy.json", {"gd_primary_samples": gd_p, "gd_secondary_samples": gd_s})

    # Train predictor
    if cfg.train_predictor:
        print("Training predictor...")
        train_predictor_model(predictor, train_waves, cfg, device, out_dir / "artifacts")
    else:
        ckpt = out_dir / "artifacts" / "predictor.pt"
        if ckpt.exists():
            predictor.load_state_dict(torch.load(ckpt, map_location="cpu"))

    predictor.to(device).eval()

    # Train controllers
    # Reactive (C=1)
    print("Training reactive controller...")
    train_controller(controller_reactive, None, train_waves, paths, cfg, device, mode="reactive")

    # Predictive (C=1+P) trained using predicted future channels
    print("Training predictive controller...")
    train_controller(controller_predictive, predictor, train_waves, paths, cfg, device, mode="predicted")

    # Evaluation
    recs = []
    print("Evaluating controllers...")
    for mode, ctrl, pred in [
        ("reactive", controller_reactive, None),
        ("oracle", controller_predictive, None),  # oracle uses same architecture; we inject oracle channels in eval
        ("predicted", controller_predictive, predictor),
    ]:
        # For oracle mode, we still pass `pred=None` and set mode="oracle" so
        # future channels are the true future.
        m = eval_controller(ctrl, pred, test_waves, paths, cfg, device, mode=mode)
        m["mode"] = mode
        recs.append(m)
        append_jsonl(out_dir / "metrics.jsonl", m)
        print(
            f"  {mode}: "
            f"NR_neg(mean)={m['nr_db_neg_mean']:.2f} dB, "
            f"NR_pos(mean)={m['nr_db_pos_mean']:.2f} dB"
        )

        # Save average attenuation-vs-frequency curve for this mode (TASLP-friendly)
        # Recompute using the same evaluation subset for determinism.
        # Store as NPZ (compact + fast to plot).
        att_curves = []
        freq_hz = None
        rng2 = np.random.default_rng(cfg.seed + 123)
        for _ in range(min(20, len(test_waves))):
            x_full = test_waves[int(rng2.integers(0, len(test_waves)))]
            x = normalize_audio(_random_clip(rng2, x_full, cfg.clip_len))
            d = np.convolve(x, paths["h_primary"], mode="full")[: len(x)].astype(np.float32)

            if mode == "reactive":
                u = x[None, :]
            else:
                spec = FuturePredictionSpec(cfg.history_len, cfg.horizon, update_stride=cfg.pred_update_stride)
                if mode == "oracle":
                    Fmat = oracle_future_matrix(x, spec)
                else:
                    assert pred is not None
                    Fmat = predicted_future_matrix(x, pred, spec, device=device)
                u = np.concatenate([x[None, :], Fmat], axis=0)

            u_t = torch.tensor(u[None, ...], device=device)
            y_t = ctrl(u_t)
            z_t = torch_secondary_path(y_t, to_torch_fir(paths["h_secondary"], device), NonlinearityConfig(kind=cfg.nonlin_kind, alpha=cfg.alpha))
            e = d + z_t.detach().cpu().numpy().reshape(-1)
            sp = attenuation_spectrum_db(d, e, nfft=2048, fs=cfg.fs)
            att_curves.append(sp["att_db"])
            if freq_hz is None:
                freq_hz = sp.get("freq_hz", None)

        if att_curves and freq_hz is not None:
            A = np.stack(att_curves, axis=0)
            (out_dir / "plots").mkdir(parents=True, exist_ok=True)  # ensure dir exists
            np.savez(
                out_dir / "plots" / f"att_curve_{mode}.npz",
                freq_hz=freq_hz,
                att_db_mean=np.mean(A, axis=0).astype(np.float32),
                att_db_std=np.std(A, axis=0).astype(np.float32),
            )

    save_json(out_dir / "metrics.json", {"records": recs})
    return out_dir

