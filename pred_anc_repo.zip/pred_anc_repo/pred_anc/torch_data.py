from __future__ import annotations

from dataclasses import dataclass
from typing import List, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset


@dataclass(frozen=True)
class WindowSpec:
    history_len: int
    prediction_len: int

    @property
    def total_len(self) -> int:
        return int(self.history_len + self.prediction_len)


class Windowed1DAudioDataset(Dataset):
    """
    Creates (history, future) pairs by sampling sliding windows from a list of 1D waveforms.

    This is intentionally simple (good for reproducible baselines).
    """

    def __init__(
        self,
        waveforms: Sequence[np.ndarray],
        history_len: int,
        prediction_len: int,
        windows_per_waveform: int = 200,
        seed: int = 42,
    ) -> None:
        self.waveforms = [np.asarray(w, dtype=np.float32) for w in waveforms if len(w) > (history_len + prediction_len + 1)]
        if not self.waveforms:
            raise ValueError("No waveforms long enough for the requested window sizes.")

        self.spec = WindowSpec(history_len=int(history_len), prediction_len=int(prediction_len))
        self.rng = np.random.default_rng(seed)

        # Pre-sample indices for determinism and speed.
        self.index: List[Tuple[int, int]] = []
        for wi, w in enumerate(self.waveforms):
            max_start = len(w) - self.spec.total_len
            if max_start <= 0:
                continue
            for _ in range(int(windows_per_waveform)):
                s = int(self.rng.integers(0, max_start))
                self.index.append((wi, s))

        if not self.index:
            raise ValueError("No windows sampled. Check waveform lengths and parameters.")

    def __len__(self) -> int:
        return len(self.index)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        wi, s = self.index[idx]
        w = self.waveforms[wi]
        seg = w[s : s + self.spec.total_len]
        hist = seg[: self.spec.history_len]
        fut = seg[self.spec.history_len :]
        return torch.from_numpy(hist).unsqueeze(0), torch.from_numpy(fut).unsqueeze(0)

