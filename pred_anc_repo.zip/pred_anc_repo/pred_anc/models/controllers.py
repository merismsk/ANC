from __future__ import annotations

import torch
import torch.nn as nn


class CausalConvController(nn.Module):
    """
    Causal 1D conv controller mapping a multichannel reference stream to anti-noise.

    Input:  (B, C, T)
    Output: (B, 1, T)
    """

    def __init__(self, in_ch: int, channels: int = 32, depth: int = 6, kernel_size: int = 7):
        super().__init__()
        assert kernel_size % 2 == 1, "use odd kernels for clean padding"

        layers: list[nn.Module] = []
        ch = in_ch
        for d in range(depth):
            dil = 2**d
            pad = (kernel_size - 1) * dil
            layers.append(nn.Conv1d(ch, channels, kernel_size=kernel_size, dilation=dil, padding=pad))
            layers.append(nn.ReLU())
            ch = channels
        layers.append(nn.Conv1d(ch, 1, kernel_size=1))
        self.net = nn.Sequential(*layers)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.net(x)
        # Convert from "same-ish with left padding" to strictly causal output.
        # The conv padding adds extra samples at the right; crop to input length.
        return y[..., : x.shape[-1]]

