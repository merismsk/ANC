from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import torch
import torch.nn as nn


class TcnPredictor(nn.Module):
    """
    Lightweight causal-ish Conv1D predictor (a strong baseline vs heavy generative models).

    Input:  (B, 1, H)
    Output: (B, 1, P)
    """

    def __init__(self, history_len: int, prediction_len: int, channels: int = 32, depth: int = 4):
        super().__init__()
        self.history_len = int(history_len)
        self.prediction_len = int(prediction_len)

        layers = []
        in_ch = 1
        dilation = 1
        k = 5
        for _ in range(depth):
            layers.append(
                nn.Conv1d(
                    in_ch,
                    channels,
                    kernel_size=k,
                    dilation=dilation,
                    padding=(k - 1) * dilation,
                )
            )
            layers.append(nn.ReLU())
            in_ch = channels
            dilation *= 2

        self.net = nn.Sequential(*layers)
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1),
            nn.Flatten(),
            nn.Linear(channels, prediction_len),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B,1,H)
        h = self.net(x)
        y = self.head(h)
        return y.unsqueeze(1)  # (B,1,P)


class TransformerPredictor(nn.Module):
    """
    Small transformer encoder baseline.
    Input:  (B, 1, H)
    Output: (B, 1, P)
    """

    def __init__(
        self,
        history_len: int,
        prediction_len: int,
        d_model: int = 64,
        nhead: int = 4,
        num_layers: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.history_len = int(history_len)
        self.prediction_len = int(prediction_len)
        self.d_model = int(d_model)

        self.input_embed = nn.Linear(1, d_model)
        self.pos = nn.Parameter(torch.randn(1, self.history_len, d_model) * 0.02)

        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            batch_first=True,
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=num_layers)

        self.pred = nn.Linear(self.history_len * d_model, prediction_len)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B,1,H) -> (B,H,1)
        x = x.transpose(1, 2)
        h = self.input_embed(x)
        h = h + self.pos

        # Causal mask (H x H)
        mask = torch.triu(torch.ones(self.history_len, self.history_len, device=h.device), diagonal=1).bool()
        h = self.enc(h, mask=mask)
        h = h.reshape(h.shape[0], -1)
        y = self.pred(h)
        return y.unsqueeze(1)


class PatchTransformerPredictor(nn.Module):
    """
    PatchTST-style Transformer for time series prediction.
    
    Instead of treating each sample as a token (H tokens, O(H²) attention),
    groups samples into patches → much fewer tokens → dramatically faster.
    
    E.g., H=128, patch_size=8 → 16 tokens instead of 128 → 64x less attention cost.
    
    State-of-the-art for time series forecasting (Nie et al., 2023).
    
    Input:  (B, 1, H)
    Output: (B, 1, P)
    """

    def __init__(
        self,
        history_len: int,
        prediction_len: int,
        patch_size: int = 8,
        d_model: int = 128,
        nhead: int = 8,
        num_layers: int = 4,
        dropout: float = 0.1,
    ) -> None:
        super().__init__()
        self.history_len = int(history_len)
        self.prediction_len = int(prediction_len)
        self.patch_size = int(patch_size)
        self.d_model = int(d_model)

        # Number of patches
        self.n_patches = self.history_len // self.patch_size
        assert self.history_len % self.patch_size == 0, \
            f"history_len ({history_len}) must be divisible by patch_size ({patch_size})"

        # Patch embedding: (patch_size,) -> (d_model,)
        self.patch_embed = nn.Linear(self.patch_size, d_model)
        
        # Learnable positional encoding for patches
        self.pos = nn.Parameter(torch.randn(1, self.n_patches, d_model) * 0.02)

        # Transformer encoder
        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=d_model * 4,
            dropout=dropout,
            batch_first=True,
        )
        self.enc = nn.TransformerEncoder(enc_layer, num_layers=num_layers)

        # Layer norm before prediction head
        self.norm = nn.LayerNorm(d_model)
        
        # Prediction head: flatten all patch representations -> future
        self.pred = nn.Sequential(
            nn.Linear(self.n_patches * d_model, d_model),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(d_model, prediction_len),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, 1, H)
        B = x.shape[0]
        x = x.squeeze(1)  # (B, H)
        
        # Reshape into patches: (B, n_patches, patch_size)
        x = x.reshape(B, self.n_patches, self.patch_size)
        
        # Embed patches: (B, n_patches, d_model)
        h = self.patch_embed(x)
        h = h + self.pos
        
        # Causal mask (n_patches x n_patches) - past patches can't attend to future
        mask = torch.triu(
            torch.ones(self.n_patches, self.n_patches, device=h.device), diagonal=1
        ).bool()
        
        h = self.enc(h, mask=mask)
        h = self.norm(h)
        
        # Flatten and predict
        h = h.reshape(B, -1)  # (B, n_patches * d_model)
        y = self.pred(h)      # (B, P)
        return y.unsqueeze(1)  # (B, 1, P)


class LinearPredictor(nn.Module):
    """
    Strong 'litmus test' baseline: linear regression from history -> future.

    Input:  (B, 1, H)
    Output: (B, 1, P)
    """

    def __init__(self, history_len: int, prediction_len: int) -> None:
        super().__init__()
        self.history_len = int(history_len)
        self.prediction_len = int(prediction_len)
        self.fc = nn.Linear(self.history_len, self.prediction_len)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B,1,H)
        x = x.squeeze(1)
        y = self.fc(x)
        return y.unsqueeze(1)

