from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import torch
import torch.nn.functional as F

from .nonlinearities import NonlinearityConfig


def torch_fir_filter_1d(x: torch.Tensor, h: torch.Tensor) -> torch.Tensor:
    """
    Causal FIR filtering using conv1d (differentiable).

    x: (B, 1, T)
    h: (L,) or (1,1,L)
    returns: (B, 1, T)
    """

    if h.ndim == 1:
        h = h.view(1, 1, -1)
    # conv1d does correlation; flip to get convolution
    h_flip = torch.flip(h, dims=[-1])
    pad = h_flip.shape[-1] - 1
    x_pad = F.pad(x, (pad, 0))
    y = F.conv1d(x_pad, h_flip)
    return y


def torch_apply_nonlinearity(x: torch.Tensor, cfg: Optional[NonlinearityConfig]) -> torch.Tensor:
    if cfg is None or cfg.kind == "linear":
        return x
    if cfg.kind == "tanh":
        return torch.tanh(float(cfg.alpha) * x)
    if cfg.kind == "clip":
        c = float(cfg.clip_level)
        return torch.clamp(x, -c, c)
    if cfg.kind == "poly3":
        g = float(cfg.poly_gain)
        return x - g * (x**3)
    raise ValueError(f"Unknown nonlinearity: {cfg.kind}")


def torch_secondary_path(y: torch.Tensor, h_sec: torch.Tensor, nonlin: Optional[NonlinearityConfig]) -> torch.Tensor:
    v = torch_fir_filter_1d(y, h_sec)
    return torch_apply_nonlinearity(v, nonlin)


def to_torch_fir(h: np.ndarray, device: torch.device) -> torch.Tensor:
    return torch.tensor(h.astype(np.float32), device=device)

