from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

import numpy as np
from scipy.signal import fftconvolve

from .nonlinearities import NonlinearityConfig, apply_nonlinearity


@dataclass(frozen=True)
class PathConfig:
    """
    Linear FIR path.

    - `h` is assumed causal and 1D.
    - If you use measured RIRs, the first sample is often aligned close to the
      direct path (sometimes delay-compensated, depending on dataset).
    """

    h: np.ndarray

    def __post_init__(self) -> None:
        if self.h.ndim != 1:
            raise ValueError("Path impulse response must be 1D")


def fir_filter(x: np.ndarray, h: np.ndarray) -> np.ndarray:
    # For long clips, FFT convolution is faster and deterministic.
    y = fftconvolve(x, h, mode="full")
    return y[: len(x)].astype(np.float32)


def secondary_path(
    y: np.ndarray,
    h_sec: np.ndarray,
    nonlin: Optional[NonlinearityConfig] = None,
) -> np.ndarray:
    v = fir_filter(y, h_sec)
    if nonlin is None:
        return v
    return apply_nonlinearity(v, nonlin).astype(np.float32)


def estimate_group_delay_samples(h: np.ndarray, eps: float = 1e-12) -> float:
    """
    Simple energy centroid as a proxy for group delay (samples).
    Not a substitute for true frequency-dependent group delay, but useful for
    sanity checks and consistent latency budgeting in simulations.
    """

    h2 = np.square(h).astype(np.float64)
    n = np.arange(len(h2), dtype=np.float64)
    return float(np.sum(n * h2) / (np.sum(h2) + eps))


def trim_or_pad(h: np.ndarray, length: int) -> np.ndarray:
    h = h.astype(np.float32)
    if len(h) == length:
        return h
    if len(h) > length:
        return h[:length]
    out = np.zeros(length, dtype=np.float32)
    out[: len(h)] = h
    return out

