from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
import soundfile as sf
from scipy.signal import resample_poly

from ..utils import normalize_audio


def esc50_default_root() -> Path:
    """
    Default location — override via ESC50_ROOT env var or root= kwarg.
    """
    import os
    env = os.environ.get("ESC50_ROOT")
    if env:
        return Path(env)
    # Fallback: ./data/ESC-50-master relative to repo root
    return Path(__file__).resolve().parents[2] / "data" / "ESC-50-master"


@dataclass(frozen=True)
class ESC50Item:
    wav_path: Path
    fold: int
    target: int
    category: str
    filename: str


class ESC50Dataset:
    """
    Minimal ESC-50 loader.

    - Reads `meta/esc50.csv`
    - Loads WAV audio from `audio/`
    - Resamples to `fs` and returns float32 in [-1, 1]
    """

    def __init__(
        self,
        root: Optional[Path] = None,
        fs: int = 16000,
        normalize: bool = True,
        folds: Optional[Iterable[int]] = None,
    ) -> None:
        self.root = (root or esc50_default_root()).expanduser()
        self.fs = int(fs)
        self.normalize = bool(normalize)

        meta_csv = self.root / "meta" / "esc50.csv"
        audio_dir = self.root / "audio"
        if not meta_csv.exists():
            raise FileNotFoundError(f"Missing ESC-50 metadata: {meta_csv}")
        if not audio_dir.exists():
            raise FileNotFoundError(f"Missing ESC-50 audio folder: {audio_dir}")

        df = pd.read_csv(meta_csv)
        if folds is not None:
            folds_set = set(int(f) for f in folds)
            df = df[df["fold"].isin(folds_set)]

        items: List[ESC50Item] = []
        for _, row in df.iterrows():
            filename = str(row["filename"])
            wav_path = audio_dir / filename
            items.append(
                ESC50Item(
                    wav_path=wav_path,
                    fold=int(row["fold"]),
                    target=int(row["target"]),
                    category=str(row["category"]),
                    filename=filename,
                )
            )
        self.items = items

    def __len__(self) -> int:
        return len(self.items)

    def _load(self, path: Path) -> Tuple[np.ndarray, int]:
        x, sr = sf.read(path, dtype="float32", always_2d=False)
        if x.ndim > 1:
            x = np.mean(x, axis=-1)
        return x.astype(np.float32), int(sr)

    def _resample(self, x: np.ndarray, sr: int) -> np.ndarray:
        if sr == self.fs:
            return x
        g = np.gcd(sr, self.fs)
        up = self.fs // g
        down = sr // g
        return resample_poly(x, up, down).astype(np.float32)

    def get_audio(self, idx: int) -> Tuple[np.ndarray, ESC50Item]:
        item = self.items[idx]
        if not item.wav_path.exists():
            raise FileNotFoundError(f"Missing file: {item.wav_path}")
        x, sr = self._load(item.wav_path)
        x = self._resample(x, sr)
        if self.normalize:
            x = normalize_audio(x)
        return x, item

