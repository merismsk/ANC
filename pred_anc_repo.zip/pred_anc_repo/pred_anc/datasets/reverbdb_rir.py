from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Tuple

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly


def reverbdb_default_root() -> Path:
    """Default location — override via REVERBDB_ROOT env var or root= kwarg."""
    import os
    env = os.environ.get("REVERBDB_ROOT")
    if env:
        return Path(env)
    # Fallback: ./data/BUT_ReverbDB relative to repo root
    return Path(__file__).resolve().parents[2] / "data" / "BUT_ReverbDB"


@dataclass(frozen=True)
class RIRItem:
    wav_path: Path
    room: str
    mic: str
    spk_setup: str


class ReverbDBRIR:
    """
    Loader for BUT ReverbDB RIR-only package.

    We only need RIR waveforms as measured impulse responses to use as:
    - primary path (noise source -> error mic), or
    - secondary path (speaker -> error mic)
    in offline simulations.
    """

    def __init__(
        self,
        root: Optional[Path] = None,
        fs: int = 16000,
        max_items: Optional[int] = 5000,
    ) -> None:
        self.root = (root or reverbdb_default_root()).expanduser()
        self.fs = int(fs)
        if not self.root.exists():
            raise FileNotFoundError(f"Missing ReverbDB root: {self.root}")

        items: List[RIRItem] = []
        # Typical path example:
        # PLACE/MicID01/SpkID01_YYYYMMDD_S/01/RIR/*.wav
        #
        # IMPORTANT: this dataset can be huge; avoid `sorted(...)` because it
        # forces a full scan + sort. We early-stop after `max_items`.
        for p in self.root.glob("*/*/SpkID*/*/RIR/*.wav"):
            parts = p.relative_to(self.root).parts
            room = parts[0]
            mic = parts[1]
            spk_setup = parts[2]
            items.append(RIRItem(wav_path=p, room=room, mic=mic, spk_setup=spk_setup))
            if max_items is not None and len(items) >= max_items:
                break

        if not items:
            raise FileNotFoundError(f"No RIR wav files found under: {self.root}")

        self.items = items

    def __len__(self) -> int:
        return len(self.items)

    def _load(self, path: Path) -> Tuple[np.ndarray, int]:
        x, sr = sf.read(path, dtype="float32", always_2d=False)
        if x.ndim > 1:
            x = np.mean(x, axis=-1)
        return x.astype(np.float32), int(sr)

    def _resample(self, x: np.ndarray, sr: int) -> np.ndarray:
        if sr == self.fs:
            return x
        g = np.gcd(sr, self.fs)
        up = self.fs // g
        down = sr // g
        return resample_poly(x, up, down).astype(np.float32)

    def get_rir(
        self,
        idx: int,
        max_len: Optional[int] = None,
        normalize_energy: bool = True,
        eps: float = 1e-12,
    ) -> Tuple[np.ndarray, RIRItem]:
        item = self.items[idx]
        if not item.wav_path.exists():
            raise FileNotFoundError(f"Missing file: {item.wav_path}")
        h, sr = self._load(item.wav_path)
        h = self._resample(h, sr)
        if max_len is not None and len(h) > max_len:
            h = h[:max_len]
        if normalize_energy:
            e = float(np.sqrt(np.sum(h**2)) + eps)
            h = (h / e).astype(np.float32)
        return h, item

