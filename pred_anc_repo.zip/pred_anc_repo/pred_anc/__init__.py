"""
Predictive / generative ANC (offline simulation toolkit).

This package is intentionally lightweight and self-contained so experiments can
run without lab hardware, using web-available audio datasets and measured room
impulse responses (RIRs) where available.
"""

from .version import __version__  # noqa: F401

