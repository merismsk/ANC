# Predictive ANC — A100 Sweep

Deep learning predictors for Active Noise Control with latency compensation.

## Quick Start

```bash
# 1. Setup environment
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2. Download datasets (~9.3 GB total)
bash download_data.sh
# This downloads ESC-50 (~600 MB) and BUT ReverbDB RIR-Only (~8.7 GB)

# 3. Run the full A100 sweep (192 experiments, ~3-4h on A100)
nohup env PYTHONUNBUFFERED=1 python run_sweep_a100.py > sweep_a100.log 2>&1 &
tail -f sweep_a100.log

# OR: Run comparable sweep (same config as local M4, 128 experiments, ~1-2h)
nohup env PYTHONUNBUFFERED=1 python run_sweep_comparable.py > sweep_comparable.log 2>&1 &
```

## Data Paths

Datasets are auto-detected from `./data/`. Override with environment variables:

```bash
export ESC50_ROOT=/path/to/ESC-50-master
export REVERBDB_ROOT=/path/to/BUT_ReverbDB
```

## Sweep Scripts

| Script | Predictors | Experiments | Config | Est. Time (A100) |
|--------|-----------|-------------|--------|-------------------|
| `run_sweep_a100.py` | Linear, TCN, Transformer, PatchTransformer | 192 | Full power (400 train, bs=128, H=128) | ~3-4h |
| `run_sweep_comparable.py` | Linear, TCN, Transformer, PatchTransformer | 128 | Same as local M4 (100 train, bs=32, H=64) | ~1-2h |

Both scripts support **automatic resume** — just re-run after interruption.

## Results

Results are saved to `runs/a100_sweep/` or `runs/comparable_sweep/`:
- `sweeps_summary.csv` — All results in one CSV
- `<run_name>/metrics.json` — Per-experiment metrics
- `<run_name>/config.json` — Per-experiment config
- `<run_name>/plots/` — Attenuation curves

## Predictors

- **Linear**: Simple linear projection (baseline)
- **TCN**: Temporal Convolutional Network
- **Transformer**: Vanilla transformer encoder
- **PatchTransformer**: PatchTST-style (Nie et al., 2023) — patches reduce O(H²) to O((H/P)²)
